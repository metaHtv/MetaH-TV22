package com.metah.tv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(5, 16, 32);
    private static final int NAVY2 = Color.rgb(10, 29, 53);
    private static final int PANEL = Color.rgb(15, 38, 66);
    private static final int GOLD = Color.rgb(232, 184, 83);
    private static final int TEXT = Color.rgb(244, 247, 251);
    private static final int MUTED = Color.rgb(165, 181, 201);
    // Preconfigured connection: obfuscation only; credentials are not cryptographically protected.
    private static final boolean PRECONFIGURED_XTREAM = true;
    private static final int CONFIG_KEY = 0x5A;
    private static final int[] CFG_SERVER = {50, 46, 46, 42, 96, 117, 117, 42, 35, 35, 34, 50, 53, 52, 116, 34, 35, 32};
    private static final int[] CFG_USER = {17, 46, 107, 56, 31, 15, 30, 98};
    private static final int[] CFG_PASS = {56, 18, 20, 30, 59, 108, 40};
    private EditText server, username, password, m3uUrl, search;
    private LinearLayout results, statusLine, connectionForm;
    private TextView xtreamTab, m3uTab, countLabel, statusLabel;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayList<Channel> channels = new ArrayList<>();
    private final ArrayList<Channel> favorites = new ArrayList<>();
    private boolean showingM3u = false, onlyFavorites = false;
    private SharedPreferences prefs;

    static class Channel {
        String name, url, group;
        boolean favorite;
        Channel(String n, String u, String g) { name=n; url=u; group=g; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHomeScreen();
    }

    private void showHomeScreen() {
        final int BLUE = Color.rgb(5, 42, 126);
        final int RED = Color.rgb(239, 24, 30);
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(BLUE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(16), dp(22), dp(18));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(0, 93, 220), Color.rgb(3, 27, 94), Color.rgb(0, 53, 157)}));

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        brandRow.setPadding(dp(4), dp(0), dp(4), dp(14));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("MetaH", 36, Color.WHITE, true);
        TextView play = text(" ▶ ", 28, RED, true);
        TextView tv = text("TV", 32, Color.WHITE, true);
        brand.addView(logo); brand.addView(play); brand.addView(tv);
        brandRow.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView expiry = text("PLAYLIST: READY", 11, Color.WHITE, true);
        brandRow.addView(expiry);
        root.addView(brandRow);

        LinearLayout mainRow = new LinearLayout(this);
        mainRow.setOrientation(LinearLayout.HORIZONTAL);
        mainRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout live = homeTile("▣", "Live", RED, 30);
        live.setOnClickListener(v -> showPlayerScreen());
        mainRow.addView(live, new LinearLayout.LayoutParams(0, dp(190), 1.25f));
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setPadding(dp(8), 0, dp(8), 0);
        LinearLayout row1 = new LinearLayout(this);
        LinearLayout movies = homeTile("▶", "Movies", RED, 16);
        movies.setOnClickListener(v -> showPlayerScreen());
        LinearLayout series = homeTile("▤", "Series", RED, 16);
        series.setOnClickListener(v -> showPlayerScreen());
        row1.addView(movies, new LinearLayout.LayoutParams(0, dp(90), 1));
        row1.addView(gapWidth(8));
        row1.addView(series, new LinearLayout.LayoutParams(0, dp(90), 1));
        LinearLayout row2 = new LinearLayout(this);
        LinearLayout account = homeTile("♧", "Account", RED, 15);
        account.setOnClickListener(v -> showPlayerScreen());
        row2.addView(account, new LinearLayout.LayoutParams(0, dp(90), 1));
        row2.addView(gapWidth(8));
        LinearLayout playlist = homeTile("⇄", "Change Playlist", RED, 13);
        playlist.setOnClickListener(v -> showPlayerScreen());
        row2.addView(playlist, new LinearLayout.LayoutParams(0, dp(90), 1));
        center.addView(row1); center.addView(gap(8)); center.addView(row2);
        mainRow.addView(center, new LinearLayout.LayoutParams(0, dp(190), 1.55f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        LinearLayout settings = homeAction("⚙", "Settings");
        settings.setOnClickListener(v -> showPlayerScreen());
        LinearLayout reload = homeAction("⟳", "Reload");
        reload.setOnClickListener(v -> { Toast.makeText(this, "MetaH TV is ready", Toast.LENGTH_SHORT).show(); });
        LinearLayout exit = homeAction("⇥", "EXIT");
        exit.setOnClickListener(v -> finish());
        actions.addView(settings, new LinearLayout.LayoutParams(-1, 0, 1));
        actions.addView(gap(7));
        actions.addView(reload, new LinearLayout.LayoutParams(-1, 0, 1));
        actions.addView(gap(7));
        actions.addView(exit, new LinearLayout.LayoutParams(-1, 0, 1));
        mainRow.addView(actions, new LinearLayout.LayoutParams(0, dp(190), 1.08f));
        root.addView(mainRow, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView footer = text("MetaH TV  •  Live channels, movies and series", 11, Color.rgb(218, 231, 255), false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(10), 0, 0);
        root.addView(footer);
        setContentView(root);
    }

    private LinearLayout homeTile(String symbol, String label, int color, int size) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(5), dp(6), dp(5), dp(6));
        tile.setBackground(shape(color, 0, 0, 9));
        tile.setFocusable(true);
        tile.setClickable(true);
        TextView icon = text(symbol, size + 12, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        TextView title = text(label, size, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        tile.addView(icon);
        tile.addView(title);
        return tile;
    }

    private LinearLayout homeAction(String symbol, String label) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(14), 0, dp(8), 0);
        tile.setBackground(shape(Color.rgb(4, 32, 92), Color.rgb(31, 127, 255), 2, 8));
        tile.setFocusable(true);
        tile.setClickable(true);
        TextView icon = text(symbol, 25, Color.WHITE, true);
        TextView title = text(label, 15, Color.WHITE, true);
        icon.setPadding(0, 0, dp(10), 0);
        tile.addView(icon);
        tile.addView(title);
        return tile;
    }

    private void showPlayerScreen() {
        prefs = getSharedPreferences("metah_tv_settings", MODE_PRIVATE);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView page = new ScrollView(this);
        page.setFillViewport(true);
        page.setBackgroundColor(NAVY);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(26));
        page.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo = text("MetaH TV", 30, GOLD, true);
        TextView tagline = text("YOUR ENTERTAINMENT, YOUR WAY", 10, MUTED, true);
        brand.addView(logo); brand.addView(tagline);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView liveBadge = text("● LIVE PLAYER", 11, GOLD, true);
        liveBadge.setPadding(dp(12), dp(8), dp(12), dp(8));
        liveBadge.setBackground(shape(PANEL, GOLD, 1, 22));
        top.addView(liveBadge);
        root.addView(top);
        root.addView(gap(18));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(gradient());
        TextView eyebrow = text("WELCOME TO", 11, GOLD, true);
        hero.addView(eyebrow);
        TextView headline = text("Entertainment\nwithout limits.", 28, TEXT, true);
        headline.setPadding(0, dp(6), 0, dp(6));
        hero.addView(headline);
        TextView desc = text("Connect your authorized IPTV service and start watching live channels.", 14, MUTED, false);
        hero.addView(desc);
        root.addView(hero, match());
        root.addView(gap(20));

        LinearLayout sectionHead = new LinearLayout(this);
        sectionHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView connectionTitle = text("CONNECT YOUR SERVICE", 14, TEXT, true);
        sectionHead.addView(connectionTitle, new LinearLayout.LayoutParams(0, -2, 1));
        TextView secure = text("● PRIVATE CONNECTION", 10, GOLD, true);
        sectionHead.addView(secure);
        root.addView(sectionHead);
        root.addView(gap(10));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabs.setBackground(shape(NAVY2, 0, 0, 16));
        xtreamTab = tab("Xtream Codes", true);
        m3uTab = tab("M3U / M3U8", false);
        tabs.addView(xtreamTab, new LinearLayout.LayoutParams(0, dp(44), 1));
        tabs.addView(m3uTab, new LinearLayout.LayoutParams(0, dp(44), 1));
        xtreamTab.setOnClickListener(v -> switchMode(false));
        m3uTab.setOnClickListener(v -> switchMode(true));
        root.addView(tabs);
        root.addView(gap(12));

        connectionForm = new LinearLayout(this);
        connectionForm.setOrientation(LinearLayout.VERTICAL);
        connectionForm.setPadding(dp(16), dp(16), dp(16), dp(16));
        connectionForm.setBackground(shape(NAVY2, 0, 0, 18));
        server = field("Server URL  ·  https://server:port");
        username = field("Username");
        password = field("Password"); password.setInputType(129);
        m3uUrl = field("Paste your authorized M3U / M3U8 URL");
        connectionForm.addView(labeled("SERVER ADDRESS", server));
        connectionForm.addView(gap(8));
        connectionForm.addView(labeled("USERNAME", username));
        connectionForm.addView(gap(8));
        connectionForm.addView(labeled("PASSWORD", password));
        connectionForm.addView(gap(8));
        connectionForm.addView(labeled("M3U PLAYLIST URL", m3uUrl));
        root.addView(connectionForm, match());
        root.addView(gap(12));

        Button connect = goldButton("CONNECT  →");
        connect.setOnClickListener(v -> { if (showingM3u) loadM3u(); else loadXtream(); });
        root.addView(connect, match());
        TextView privacy = text("Your password is kept in memory only and is not saved to app settings.", 11, MUTED, false);
        privacy.setPadding(dp(4), dp(8), dp(4), 0);
        root.addView(privacy);
        root.addView(gap(22));

        LinearLayout channelHead = new LinearLayout(this);
        channelHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView channelTitle = text("YOUR CHANNELS", 14, TEXT, true);
        channelHead.addView(channelTitle, new LinearLayout.LayoutParams(0, -2, 1));
        countLabel = text("0 CHANNELS", 10, GOLD, true);
        channelHead.addView(countLabel);
        root.addView(channelHead);
        root.addView(gap(10));

        search = field("Search channels or categories…");
        search.setSingleLine(true);
        root.addView(search, match());
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { renderChannels(); }
            public void afterTextChanged(Editable e) {}
        });
        root.addView(gap(8));
        LinearLayout filterRow = new LinearLayout(this);
        Button allBtn = subtleButton("All channels");
        Button favBtn = subtleButton("★ Favorites");
        filterRow.addView(allBtn, new LinearLayout.LayoutParams(0, dp(42), 1));
        filterRow.addView(gapWidth(8));
        filterRow.addView(favBtn, new LinearLayout.LayoutParams(0, dp(42), 1));
        allBtn.setOnClickListener(v -> { onlyFavorites=false; renderChannels(); });
        favBtn.setOnClickListener(v -> { onlyFavorites=true; renderChannels(); });
        root.addView(filterRow);
        root.addView(gap(10));

        statusLine = new LinearLayout(this);
        statusLine.setGravity(Gravity.CENTER_VERTICAL);
        statusLine.setPadding(dp(12), dp(12), dp(12), dp(12));
        statusLine.setBackground(shape(PANEL, 0, 0, 12));
        statusLabel = text("Ready when you are. Connect a playlist to begin.", 13, MUTED, false);
        statusLine.addView(statusLabel);
        root.addView(statusLine, match());
        root.addView(gap(10));
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results, match());
        setContentView(page);
        restoreSettings();
        if (PRECONFIGURED_XTREAM) {
            server.setText(decodeConfig(CFG_SERVER));
            username.setText(decodeConfig(CFG_USER));
            password.setText(decodeConfig(CFG_PASS));
            switchMode(false);
            setStatus("Secure display mode: connecting to your configured service…");
            server.post(this::loadXtream);
        }
        renderChannels();
    }

    @Override public void onBackPressed() {
        showHomeScreen();
    }

    private void switchMode(boolean m3u) {
        showingM3u = m3u;
        xtreamTab.setBackground(shape(m3u ? NAVY2 : GOLD, 0, 0, 12));
        m3uTab.setBackground(shape(m3u ? GOLD : NAVY2, 0, 0, 12));
        xtreamTab.setTextColor(m3u ? MUTED : NAVY);
        m3uTab.setTextColor(m3u ? NAVY : MUTED);
        server.setVisibility(m3u || PRECONFIGURED_XTREAM ? View.GONE : View.VISIBLE);
        username.setVisibility(m3u || PRECONFIGURED_XTREAM ? View.GONE : View.VISIBLE);
        password.setVisibility(m3u || PRECONFIGURED_XTREAM ? View.GONE : View.VISIBLE);
        m3uUrl.setVisibility(m3u ? View.VISIBLE : View.GONE);
        connectionForm.setVisibility((PRECONFIGURED_XTREAM && !m3u) ? View.GONE : View.VISIBLE);
        updateFormLabels(m3u);
    }

    private void updateFormLabels(boolean m3u) {
        // The input controls remain in the same premium card; only relevant fields are shown.
        for (int i=0;i<connectionForm.getChildCount();i++) {
            View child=connectionForm.getChildAt(i);
            if (child instanceof LinearLayout) {
                LinearLayout row=(LinearLayout)child;
                if (row.getChildCount()>1 && row.getChildAt(1) instanceof EditText) {
                    EditText e=(EditText)row.getChildAt(1);
                    boolean visible = e==m3uUrl ? m3u : (e==server||e==username||e==password) && !m3u;
                    row.setVisibility(visible ? View.VISIBLE : View.GONE);
                }
            }
        }
    }

    private void loadXtream() {
        final String base=server.getText().toString().trim().replaceAll("/+$", ""), user=username.getText().toString().trim(), pass=password.getText().toString().trim();
        if(base.isEmpty()||user.isEmpty()||pass.isEmpty()){toast("Enter server URL, username and password.");return;}
        if (!PRECONFIGURED_XTREAM) prefs.edit().putString("server",base).putString("username",user).apply();
        hideKeyboard(); setStatus("Connecting to your Xtream service…");
        worker.execute(() -> { try {
            String api=base+"/player_api.php?username="+enc(user)+"&password="+enc(pass)+"&action=get_live_streams";
            String body=get(api); JSONArray arr=new JSONArray(body); ArrayList<Channel> found=new ArrayList<>();
            for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o==null)continue; String name=o.optString("name","Unnamed channel"); String id=o.optString("stream_id",""); String ext=o.optString("container_extension","ts"); if(!id.isEmpty()) found.add(new Channel(name,base+"/live/"+enc(user)+"/"+enc(pass)+"/"+id+"."+ext,o.optString("category_name","Live TV")));}
            runOnUiThread(() -> {channels.clear();channels.addAll(found);renderChannels();setStatus(found.size()>0?"Connected successfully. Choose a channel to play.":"No channels returned. Check your service details.");toast(found.size()+" channels loaded.");});
        } catch(Exception e){runOnUiThread(() -> setStatus("Connection failed. Check the server address, credentials and internet."));} });
    }

    private void loadM3u() {
        final String link=m3uUrl.getText().toString().trim(); if(link.isEmpty()){toast("Paste an M3U playlist URL first.");return;}
        prefs.edit().putString("m3u",link).apply(); hideKeyboard(); setStatus("Loading playlist…");
        worker.execute(() -> { try {
            String body=get(link); String[] lines=body.split("\\r?\\n"); ArrayList<Channel> found=new ArrayList<>(); String name="Channel"; String group="";
            for(String raw:lines){String line=raw.trim(); if(line.startsWith("#EXTINF")){int comma=line.lastIndexOf(','); name=comma>=0?line.substring(comma+1).trim():"Channel"; int gi=line.indexOf("group-title=\""); if(gi>=0){int end=line.indexOf('"',gi+13); if(end>gi)group=line.substring(gi+13,end);} } else if(!line.isEmpty()&&!line.startsWith("#")&&(line.startsWith("http://")||line.startsWith("https://"))){found.add(new Channel(name,line,group.isEmpty()?"Playlist":group));name="Channel";group="";}}
            runOnUiThread(() -> {channels.clear();channels.addAll(found);renderChannels();setStatus(found.size()>0?"Playlist loaded. Select a channel to start playback.":"No playable URLs found in this playlist.");toast(found.size()+" channels loaded.");});
        } catch(Exception e){runOnUiThread(() -> setStatus("Could not load playlist. Check the URL and network."));} });
    }

    private void renderChannels() {
        if(results==null)return;
        results.removeAllViews();
        String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown=0;
        for(Channel c:channels){
            if(onlyFavorites&&!c.favorite)continue;
            if(!q.isEmpty()&&!c.name.toLowerCase(Locale.ROOT).contains(q)&&!c.group.toLowerCase(Locale.ROOT).contains(q))continue;
            LinearLayout card=new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(12),dp(10),dp(10),dp(10)); card.setBackground(shape(PANEL,0,0,14));
            TextView icon=text("▶",18,GOLD,true); icon.setGravity(Gravity.CENTER); icon.setBackground(shape(NAVY2,GOLD,1,12));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(42),dp(42)); ip.rightMargin=dp(12); card.addView(icon,ip);
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            TextView nm=text(c.name,14,TEXT,true); nm.setMaxLines(2);
            TextView gr=text(c.group==null||c.group.isEmpty()?"LIVE CHANNEL":c.group,10,MUTED,false);
            info.addView(nm); info.addView(gr); card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button fav=subtleButton(c.favorite?"★":"☆"); fav.setTextColor(c.favorite?GOLD:MUTED); fav.setMinWidth(dp(42));
            fav.setOnClickListener(v->{c.favorite=!c.favorite;renderChannels();}); card.addView(fav);
            card.setFocusable(true); card.setClickable(true); card.setOnClickListener(v->{Intent i=new Intent(this,PlayerActivity.class);i.putExtra("url",c.url);i.putExtra("name",c.name);startActivity(i);});
            LinearLayout.LayoutParams cp=match(); cp.bottomMargin=dp(8); results.addView(card,cp); shown++;
        }
        countLabel.setText(shown+" CHANNEL"+(shown==1?"":"S"));
        if(shown==0){TextView empty=text(channels.isEmpty()?"Your channels will appear here after connecting.":"No channels match this filter.",13,MUTED,false);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(10),dp(24),dp(10),dp(24));results.addView(empty,match());}
    }

    private View labeled(String label, EditText edit) {
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);
        TextView l=text(label,10,MUTED,true);l.setPadding(dp(2),0,0,dp(5));wrap.addView(l);wrap.addView(edit,match());return wrap;
    }
    private void restoreSettings(){server.setText(prefs.getString("server",""));username.setText(prefs.getString("username",""));m3uUrl.setText(prefs.getString("m3u",""));switchMode(false);}
    private String get(String address)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestProperty("User-Agent","MetaH-TV/1.1");try{int code=c.getResponseCode();InputStream in=code>=200&&code<400?c.getInputStream():c.getErrorStream();if(in==null)throw new Exception("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l).append('\n');if(code<200||code>=400)throw new Exception("HTTP "+code);return s.toString();}finally{c.disconnect();}}
    private String decodeConfig(int[] value) {
        StringBuilder out = new StringBuilder(value.length);
        for (int item : value) out.append((char)(item ^ CONFIG_KEY));
        return out.toString();
    }
    private String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private void setStatus(String s){runOnUiThread(()->{if(statusLabel!=null)statusLabel.setText(s);});}
    private TextView tab(String s,boolean active){TextView t=text(s,13,active?NAVY:MUTED,true);t.setGravity(Gravity.CENTER);t.setBackground(shape(active?GOLD:NAVY2,0,0,12));t.setFocusable(true);return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setHint(hint);e.setTextSize(14);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackground(shape(Color.rgb(7,21,39),Color.rgb(46,75,107),1,10));e.setSelectAllOnFocus(false);e.setMinimumHeight(dp(48));return e;}
    private Button goldButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(NAVY);b.setTextSize(14);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setBackground(shape(GOLD,0,0,14));b.setFocusable(true);b.setMinHeight(dp(50));return b;}
    private Button subtleButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(12);b.setAllCaps(false);b.setBackground(shape(NAVY2,0,0,12));b.setFocusable(true);b.setMinHeight(dp(40));return b;}
    private GradientDrawable shape(int color,int strokeColor,int strokeWidth,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(strokeWidth>0)d.setStroke(dp(strokeWidth),strokeColor);return d;}
    private android.graphics.drawable.Drawable gradient(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(19,51,83),Color.rgb(8,23,43),Color.rgb(30,44,62)});d.setCornerRadius(dp(20));d.setStroke(dp(1),Color.rgb(65,88,116));return d;}
    private LinearLayout.LayoutParams match(){return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);}
    private View gap(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;}
    private View gapWidth(int w){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1));return v;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(server.getWindowToken(),0);}catch(Exception ignored){}}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
