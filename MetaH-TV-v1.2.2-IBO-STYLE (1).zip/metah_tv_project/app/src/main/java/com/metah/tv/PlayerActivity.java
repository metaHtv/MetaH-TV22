package com.metah.tv;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    private ExoPlayer player;
    private static final int NAVY = Color.rgb(5,16,32);
    private static final int GOLD = Color.rgb(232,184,83);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        String url=getIntent().getStringExtra("url");
        String name=getIntent().getStringExtra("name");
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        PlayerView view=new PlayerView(this); view.setUseController(true); view.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        root.addView(view,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.VERTICAL); top.setPadding(dp(18),dp(14),dp(18),dp(14));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xDD051020,0x00051020}); top.setBackground(bg);
        TextView brand=new TextView(this); brand.setText("MetaH TV  •  NOW PLAYING"); brand.setTextColor(GOLD); brand.setTextSize(11); brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD); top.addView(brand);
        TextView title=new TextView(this); title.setText(name==null?"Live channel":name); title.setTextColor(Color.WHITE); title.setTextSize(19); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setPadding(0,dp(4),0,0); top.addView(title);
        root.addView(top,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,Gravity.TOP));
        TextView back=new TextView(this); back.setText("‹  BACK"); back.setTextColor(Color.WHITE); back.setTextSize(13); back.setPadding(dp(14),dp(10),dp(14),dp(10)); back.setBackground(roundRect(0xCC0F2642)); back.setFocusable(true); back.setOnClickListener(v->finish());
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT,Gravity.BOTTOM|Gravity.START); bp.setMargins(dp(18),0,0,dp(18)); root.addView(back,bp);
        setContentView(root);
        player=new ExoPlayer.Builder(this).build(); view.setPlayer(player);
        player.addListener(new Player.Listener(){});
        if(url!=null&&!url.trim().isEmpty()){player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.play();}
    }
    private GradientDrawable roundRect(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(12));d.setStroke(dp(1),0x55E8B853);return d;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onStop(){super.onStop();if(player!=null){player.release();player=null;}}
}
